
     <section id="newsletter" >

        <div class="container" style="height: 100%;" >


            <div class="row">

                <h3>SYARAT PELAYANAN</h3>

                <div class="form-container">

                
    

                </div>

            </div>

        </div>


    </section>
     
      <section id="contact" class="section-padding">

        <div class="container">

            <h2><?= $sp->nama_sp; ?></h2>

                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Syarat</th>
                            
                        </tr>
                    </thead>
                   
                    <tbody>
                    <?php
                                    $no=1;
                                    foreach ($dt_syarat as $c): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td ><div align="left"><?= $c->nama_syarat; ?></div></td>
                                
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>

      

        

      

    </section>
     