
     <section id="newsletter" >

        <div class="container" style="height: 100%;" >


            <div class="row">

                <h3><?= $judul; ?></h3>

           

            </div>

        </div>


    </section>
    <section id="contact" class="section-padding">

      
       

            <div class="container">

                <h2>Silahkan sampaikan kritik, saran dan masukkan anda untuk Aplikasi PINANDU. Identitas anda disembunyikan !!</h2>

               
                     <?php  
             echo validation_errors();                       
    echo form_open('site/kirim_saran','class="contact-form"'); ?>

                    

                        <div class="form-group">

                            <?= $captcha ?>
<?php if(validation_errors()) { ?>
                    <?php echo validation_errors() ?>
                    <?php } ?>
                        </div>

                        <div class="form-group">

                           
                             <input type="text" name="captcha" class="form-control"  placeholder="Masukan kode Captcha diatas" required>

                        </div>
                         

                 

                   

                        <div class="form-group">

                            <textarea class="form-control" rows="3" name="pengaduan" placeholder="Pesan anda..."></textarea>

                        </div>

                    

                    <button type="submit" name="submit" class="btn btn-blue">Kirim</button>

                </form>

            </div>

     


        <!-- Google Map -->

       

        <!-- Contact Form -->


    </section>
     

     