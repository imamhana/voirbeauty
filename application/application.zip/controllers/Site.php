<?php

class Site extends CI_Controller{
  function __construct()
    {
        parent::__construct();
      
        $this->load->model('m_user_umum');
        $this->load->model('m_admin');
        $this->load->model('m_umum');
    }
        function create_captcha()
    {
        $options = array(
            'img_path' => 'captcha/',
            'img_url' => base_url('captcha'),
            'img_width' => '100',
            'img_height' => '40',
            'img_id'       => 'Imageid',
            'expiration' => 7200,
            'word_length'   => 4,
            'font_size'     => 50,
            'pool' => '0123456789',
            'expiration' => 100,
            'colors' => array(
                'background' => array(0, 0, 0),
                'border' => array(255, 255, 255),
                'text' => array(255, 255, 255),
                'grid' => array(255, 40, 40)
            )
        );
        $cap = create_captcha($options);
        $image = $cap['image'];
        $this->session->set_userdata('captchaword', $cap['word']);
        return $image;
    }
    function check_captcha()
    {
        if ($this->input->post('captcha') == $this->session->userdata('captchaword')) {

            return true;
        } else {

            $this->form_validation->set_message('check_captcha', 'Captcha tidak sama');

            return false;
        }
    }
        function kritiksaran()
    {

        $data = array(
            'judul' => 'Kritik, Saran dan Masukkan',
             'captcha' => $this->create_captcha(),
        );
       $this->template->load('site/template2', 'site/kritiksaran', $data);
    }
    function kirim_saran()
    {

        $this->db->set('id_pengaduan', 'UUID()', FALSE);
        $this->form_validation->set_rules('pengaduan', 'pengaduan', 'required');
         $this->form_validation->set_rules('captcha', 'Captcha', 'trim|callback_check_captcha|required');
        if ($this->form_validation->run() === FALSE) {
            $notif = "Gagal Memasukan Data/Captcha Salah";
            $this->session->set_flashdata('delete', $notif);
           redirect('site/kritiksaran');
        } 
        else {

            $this->m_umum->set_data("pengaduan");
            $notif = "Data berhasil dikirim";
            $this->session->set_flashdata('success', $notif);
          redirect('site/kritiksaran');
        }
    }
 
    public function index()
    {
$data['dt_sp']=$this->m_umum->get_sp();
        $this->load->view('site/index',$data);
    }
function view_syarat($id_sp)
    {

        $data = array(
           'dt_syarat' => $this->m_admin->get_detail_sp($id_sp),
           'sp' => $this->m_umum->ambil_data('sp', 'id_sp', $id_sp),
           
           
        );
        $this->template->load('site/template2', 'site/view_syarat', $data);
    }
}

 